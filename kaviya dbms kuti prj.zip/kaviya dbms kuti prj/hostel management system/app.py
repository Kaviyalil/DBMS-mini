from flask import Flask, render_template, redirect, request, url_for
from flask_mysqldb import MySQL

app = Flask(__name__)
app.secret_key = 'secret_key'

# MySQL Configurations
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = '2005'
app.config['MYSQL_DB'] = 'hostel'
mysql = MySQL(app)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/rooms')
def rooms():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM roomdetails")
    roominfo = cur.fetchall()
    cur.close()
    return render_template('rooms.html', rooms=roominfo)

@app.route('/search', methods=['POST'])
def search():
    if request.method == "POST":
        search_term = request.form['room_id']
        cur = mysql.connection.cursor()
        query = "SELECT * FROM roomdetails WHERE id LIKE %s"
        cur.execute(query, ('%' + search_term + '%',))
        search_results = cur.fetchmany(size=1)
        cur.close()
        return render_template('rooms.html', rooms=search_results)

@app.route('/insert', methods=['POST'])
def insert():
    if request.method == "POST":
        student_name = request.form['student_name']
        room_number = request.form['room_number']
        description = request.form['description']
        fees_paid = request.form['fees_paid']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO roomdetails (student_name, room_number, description, fees_paid) VALUES (%s, %s, %s, %s)", 
                    (student_name, room_number, description, fees_paid))
        mysql.connection.commit()
        return redirect(url_for('rooms'))

@app.route('/delete/<string:id_data>', methods=['GET'])
def delete(id_data):
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM roomdetails WHERE id = %s", (id_data,))
    mysql.connection.commit()
    return redirect(url_for('rooms'))

@app.route('/update', methods=['POST'])
def update():
    if request.method == 'POST':
        id_data = request.form['room_id']
        student_name = request.form['student_name']
        room_number = request.form['room_number']
        description = request.form['description']
        fees_paid = request.form['fees_paid']

        cur = mysql.connection.cursor()
        cur.execute("UPDATE roomdetails SET student_name = %s, room_number = %s, description = %s, fees_paid = %s WHERE id = %s", 
                    (student_name, room_number, description, fees_paid, id_data))
        mysql.connection.commit()
        return redirect(url_for('rooms'))

if __name__ == "__main__":
    app.run(debug=True)
