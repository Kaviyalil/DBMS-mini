CREATE DATABASE hostel;

USE hostel;

CREATE TABLE roomdetails (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_name VARCHAR(255) NOT NULL,
    room_number VARCHAR(10) NOT NULL,
    description TEXT,
    fees_paid VARCHAR(10)
);
-- Inserting 5 values with Tamil names in Tanglish into the roomdetails table
INSERT INTO roomdetails (student_name, room_number, description, fees_paid) 
VALUES
('Arun Kumar', '201A', 'Oru madi room, balcony-oda', 'Aam'),
('Meenakshi', '202B', 'Rendu madi room, tharayinai arugil', 'Illai'),
('Sivasankar', '203C', 'Mun gate aruge oru madi room', 'Aam'),
('Komathi', '204D', 'Rendu madi room, mel madiyil', 'Illai'),
('Vignesh', '205E', 'Oru madi room, padikkum mesaiyoda', 'Aam');

select * from roomdetails;